
class GlobalVars:
    max_load = 4
    max_demand = 4
    Start_SOC = 80.
    t_limit = 10.
    velocity = 50.
    # Vehicle Energy Consumption args
    mc = 4100
    g = 9.81
    w = 1000
    Cd = 0.7
    A = 6.66
    Ad = 1.2041
    Cr = 0.01
    motor_d = 1.18
    motor_r = 0.85
    battery_d = 1.11
    battery_r = 0.93
    Pm_param1 = 0.5 * Cd * A * Ad * (velocity / 3.6) ** 2
    Pm_param2 = g * Cr
    positive_param = motor_d * battery_d
    negative_param = motor_r * battery_r
    k = 10