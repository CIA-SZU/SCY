from torch.utils.data import Dataset
import torch
import os
import pickle
import numpy as np
import random
from problems.evrpctec.state_evrpctec import StateEVRPCTEC
from utils.beam_search import beam_search
from utils.global_vars import GlobalVars

class EVRPCTEC(object):
    NAME = 'evrpctec'

    @staticmethod
    def make_dataset(*args, **kwargs):
        return EVRPCTECDataset(*args, **kwargs)

    @staticmethod
    def make_state(*args, **kwargs):
        return StateEVRPCTEC.initialize(*args, **kwargs)

    @staticmethod
    def beam_search(input, beam_size, expand_size=None,
                    compress_mask=False, model=None, max_calc_batch_size=4096):
        assert model is not None, "Provide model"

        fixed = model.precompute_fixed(input)

        def propose_expansions(beam):
            return model.propose_expansions(
                beam, fixed, expand_size, normalize=True, max_calc_batch_size=max_calc_batch_size
            )

        state = EVRPCTEC.make_state(
            input, visited_dtype=torch.int64 if compress_mask else torch.uint8
        )

        return beam_search(state, beam_size, propose_expansions)


def generate_data(num_samples, graph_size, c_size):
    depot = torch.randint(40, 60, (num_samples, 1, 2))
    loc_t = torch.randint(0, 101, (num_samples, graph_size, 2))
    coordinate_x1 = torch.randint(10, 50, (num_samples, 20, 1))
    coordinate_x2 = torch.randint(51, 91, (num_samples, 20, 1))
    coordinate_y1 = torch.randint(10, 50, (num_samples, 20, 1))
    coordinate_y2 = torch.randint(51, 91, (num_samples, 20, 1))
    stations = torch.zeros(num_samples, c_size-1, 2)
    for i in range(c_size-1):
        if i % 4 == 0:
            stations[:, i, :] = torch.cat((coordinate_x1[:, i, :], coordinate_y1[:, i, :]), dim=1)
        if i % 4 == 1:
            stations[:, i, :] = torch.cat((coordinate_x1[:, i, :], coordinate_y2[:, i, :]), dim=1)
        if i % 4 == 2:
            stations[:, i, :] = torch.cat((coordinate_x2[:, i, :], coordinate_y1[:, i, :]), dim=1)
        if i % 4 == 3:
            stations[:, i, :] = torch.cat((coordinate_x2[:, i, :], coordinate_y2[:, i, :]), dim=1)
    loc = torch.cat((depot, stations, loc_t), dim=1)
    Elevations = torch.randint(0, 101, (num_samples, graph_size + c_size))
    Elevations = (Elevations / 1000)
    distin = torch.cat((torch.ones(num_samples, c_size),
                        torch.zeros(num_samples, graph_size)), dim=1)
    distin[:, 0] = torch.zeros(1)
    demands = torch.randint(1, GlobalVars.max_demand * 2 + 1, (num_samples, graph_size + c_size)) * 0.125 * 0.25
    demands = demands / float(GlobalVars.max_load)
    demands[:, 0: c_size] = 0
    serve_times = torch.cat((torch.zeros(num_samples, c_size),
                            torch.full((num_samples, graph_size), 0.33)), dim=1)
    #  If the scale of the problem is small, it is directly calculated when making the data
    if num_samples <= 12800:
        seq_len = c_size + graph_size
        distances = torch.zeros(num_samples, seq_len, seq_len)
        for i in range(seq_len):
            distances[:, i] = torch.sqrt(
                torch.sum(torch.pow(loc[:, i:i + 1, :] - loc[:, :, :], 2), dim=2))
        slope = torch.zeros(num_samples, seq_len, seq_len)
        for i in range(seq_len):
            slope[:, i] = torch.clamp(
                torch.div((Elevations[:, i:i + 1] - Elevations[:, :]), distances[:, i] + 0.000001), min=-0.10,
                max=0.10)
        return list(zip(
            np.full(num_samples, c_size).tolist(),
            loc.tolist(),
            Elevations.tolist(),
            distin.tolist(),
            demands.tolist(),
            serve_times.tolist(),
            distances.tolist(),
            slope.tolist()
        ))
    else:
        return list(zip(
            np.full(num_samples, c_size).tolist(),
            loc.tolist(),
            Elevations.tolist(),
            distin.tolist(),
            demands.tolist(),
            serve_times.tolist(),
        ))


class EVRPCTECDataset(Dataset):

    def __init__(self, filename=None, size=50, p_size=4, num_samples=1000000, offset=0):
        super(EVRPCTECDataset, self).__init__()

        self.data_set = []
        if filename is not None:
            assert os.path.splitext(filename)[1] == '.pkl'

            with open(filename, 'rb') as f:
                data = pickle.load(f)
                self.data = [
                    {
                        'p_size': torch.tensor(p_size),
                        'loc': torch.FloatTensor(loc),
                        'Elevations': torch.FloatTensor(Elevations),
                        'distin': torch.FloatTensor(distin),
                        'demands': torch.FloatTensor(demands),
                        'serve_time': torch.FloatTensor(serve_time),
                        'distances': torch.FloatTensor(distances),
                        'slope': torch.FloatTensor(slope),
                    }
                    for p_size, loc, Elevations, distin, demands, serve_time,
                        distances, slope in (data[offset:offset + num_samples])
                ]
            print("dataset load finished")
        else:
            data = generate_data(num_samples, size, p_size)
            if num_samples <= 12800:
                self.data = [
                    {
                        'p_size': torch.tensor(p_size),
                        'loc': torch.FloatTensor(loc),
                        'Elevations': torch.FloatTensor(Elevations),
                        'distin': torch.FloatTensor(distin),
                        'demands': torch.FloatTensor(demands),
                        'serve_time': torch.FloatTensor(serve_time),
                        'distances': torch.FloatTensor(distances),
                        'slope': torch.FloatTensor(slope),
                    }
                    for p_size, loc, Elevations, distin, demands, serve_time,
                        distances, slope in (data[offset:offset + num_samples])
                ]
            else:
                self.data = [
                    {
                        'p_size': torch.tensor(p_size),
                        'loc': torch.FloatTensor(loc),
                        'Elevations': torch.FloatTensor(Elevations),
                        'distin': torch.FloatTensor(distin),
                        'demands': torch.FloatTensor(demands),
                        'serve_time': torch.FloatTensor(serve_time),
                    }
                    for p_size, loc, Elevations, distin, demands, serve_time
                        in (data[offset:offset + num_samples])
                ]

        self.size = len(self.data)


    def __len__(self):
        return self.size

    def __getitem__(self, idx):
        return self.data[idx]
