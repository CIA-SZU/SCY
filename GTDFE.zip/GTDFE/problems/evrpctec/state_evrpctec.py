import torch
from typing import NamedTuple
from utils.boolmask import mask_long2bool, mask_long_scatter
from utils.global_vars import GlobalVars


class StateEVRPCTEC(NamedTuple):

    p_size: torch.Tensor
    coords: torch.Tensor
    Elevations: torch.Tensor
    distin: torch.Tensor
    demands: torch.Tensor
    serve_time: torch.Tensor
    distances: torch.Tensor
    slope: torch.Tensor
    charging_num: torch.Tensor
    # If this state contains multiple copies (i.e. beam search) for the same instance, then for memory efficiency
    # the coords and prizes tensors are not kept multiple times, so we need to use the ids to index the correct rows.
    # shape(batch_dim, 1)  [0, 1, ..., 1023]
    ids: torch.Tensor  # Keeps track of original fixed data index of rows
    prev_a: torch.Tensor
    visited_: torch.Tensor  # Keeps track of nodes that have been visited
    cur_load: torch.Tensor
    cur_SOC: torch.Tensor
    cur_time: torch.Tensor
    i: torch.Tensor  # Keeps track of step

    @property
    def visited(self):
        if self.visited_.dtype == torch.uint8:
            return self.visited_
        else:
            return mask_long2bool(self.visited_, n=self.coords.size(-2))

    @property
    def dist(self):
        return (self.coords[:, :, None, :] - self.coords[:, None, :, :]).norm(p=2, dim=-1)

    def __getitem__(self, key):
        assert torch.is_tensor(key) or isinstance(key, slice)  # If tensor, idx all tensors by this tensor:
        return self._replace(
            ids=self.ids[key],
            prev_a=self.prev_a[key],
            visited_=self.visited_[key],
            cur_load=self.cur_load[key],
            cur_SOC=self.cur_SOC[key],
            cur_time=self.cur_time[key],

        )

    # Warning: cannot override len of NamedTuple, len should be number of fields, not batch size
    # def __len__(self):
    #     return len(self.used_capacity)

    @staticmethod
    def initialize(input, visited_dtype=torch.uint8):
        p_size = int(input['p_size'][-1])
        loc = input['loc']
        Elevations = input['Elevations']
        distin = input['distin'][:, :, None]
        demands = input['demands'][:, :, None]
        serve_time = input['serve_time'][:, :, None]
        batch_size, node_num, _ = loc.size()
        device = loc.device  # cuda device
        if len(input) == 8:
            distances = input['distances']
            slope = input['slope']
        else:
            distances = torch.zeros(batch_size, node_num, node_num, device=device)
            for i in range(node_num):
                distances[:, i] = torch.sqrt(
                    torch.sum(torch.pow(loc[:, i:i + 1, :] - loc[:, :, :], 2), dim=2))
            slope = torch.zeros(batch_size, node_num, node_num, device=device)
            for i in range(node_num):
                slope[:, i] = torch.clamp(
                    torch.div((Elevations[:, i:i + 1] - Elevations[:, :]), distances[:, i] + 0.000001), min=-0.10,
                    max=0.10)

        return StateEVRPCTEC(
            p_size=p_size,
            coords=loc,
            Elevations=Elevations,
            distin=distin,
            demands=demands,
            serve_time=serve_time,
            distances=distances,
            slope=slope,
            charging_num=p_size-1,
            ids=torch.arange(batch_size, dtype=torch.int64, device=device)[:, None],  # Add steps dimension
            prev_a=torch.zeros(batch_size, dtype=torch.long, device=device),
            visited_=(  # Visited as mask is easier to understand, as long more memory efficient
                # Keep visited_ with depot so we can scatter efficiently (if there is an action for depot)
                torch.zeros(
                    batch_size, 1, node_num,
                    dtype=torch.uint8, device=device
                )
                if visited_dtype == torch.uint8
                else torch.zeros(batch_size, 1, (node_num + 63) // 64, dtype=torch.int64, device=device)  # Ceil
            ),
            cur_load=torch.full((batch_size, node_num, 1), 1., device=device),
            cur_SOC=torch.full((batch_size, node_num, 1), GlobalVars.Start_SOC, device=device),
            cur_time=torch.full((batch_size, node_num, 1), GlobalVars.t_limit, device=device),
            i=torch.zeros(1, dtype=torch.int64, device=device),
        )

    def get_cur_SOC(self):
        return self.cur_SOC

    def get_cur_load(self):
        return self.cur_load

    def get_cur_time(self):
        return self.cur_time

    def get_current_node(self):
        return self.prev_a[:, None]

    def all_finished(self):
        # All must be returned to depot (and at least 1 step since at start also prev_a == 0)
        # This is more efficient than checking the mask
        return (self.prev_a == 0).all() and self.visited_[:, :, self.p_size:].all()

    def update(self, selected):

        assert self.i.size(0) == 1, "Can only update if state represents single step"

        prev_a = self.prev_a
        distance = self.distances[torch.arange(self.distances.size(0)), prev_a, selected].unsqueeze(1)
        slope = self.slope[torch.arange(self.distances.size(0)), prev_a, selected].unsqueeze(1)

        depot = selected.eq(0)
        charging_station = (selected.gt(0) & selected.le(self.charging_num))
        station_depot = selected.le(self.charging_num)
        customer = selected.gt(self.charging_num)

        all_loads = self.cur_load[:, :, 0].clone()
        all_demands = self.demands[:, :, 0].clone()
        all_SOC = self.cur_SOC[:, :, 0].clone()
        all_time = self.cur_time[:, :, 0].clone()

        time_cons = distance / GlobalVars.velocity
        mass = (GlobalVars.mc + all_loads[:, 0] * GlobalVars.max_load * GlobalVars.w).unsqueeze(1)
        soc_consume = self.calculate_soc_consume(mass, slope, time_cons)

        all_SOC -= soc_consume
        SOC_needed = GlobalVars.Start_SOC - all_SOC[:, 0:1]
        all_SOC[station_depot] = GlobalVars.Start_SOC
        cur_distin = torch.gather(self.distin[:, :, 0], index=selected[:, None], dim=1)
        time_to_charge = SOC_needed / GlobalVars.Start_SOC * cur_distin
        time_cons[charging_station] += time_to_charge[charging_station]
        time_to_serve = torch.gather(self.serve_time[:, :, 0], dim=1, index=selected[:, None])
        time_cons[customer] += time_to_serve[customer]

        all_time -= time_cons
        all_time[depot] = GlobalVars.t_limit

        load = torch.gather(all_loads, 1, selected.unsqueeze(1))
        demand = torch.gather(all_demands, 1, selected.unsqueeze(1))

        if customer.any():
            new_load = torch.clamp(load - demand, min=0)
            new_demand = torch.clamp(demand - load, min=0)
            customer_idx = customer.nonzero(as_tuple=False).squeeze()
            all_loads[customer_idx] = new_load[customer_idx]
            all_demands[customer_idx, selected[customer_idx]] = new_demand[customer_idx].view(-1)
            all_demands[customer_idx, 0] = -1. + new_load[customer_idx].view(-1)

        if depot.any():
            all_loads[depot.nonzero(as_tuple=False).squeeze()] = 1.
            all_demands[depot.nonzero(as_tuple=False).squeeze(), 0] = 0.

        if self.visited_.dtype == torch.uint8:
            # Note: here we do not subtract one as we have to scatter so the first column allows scattering depot
            # Add one dimension since we write a single value
            visited_ = self.visited_.scatter(-1, selected[:, None, None], 1)
        else:
            # This works, by check_unset=False it is allowed to set the depot visited a second a time
            visited_ = mask_long_scatter(self.visited_, selected[:, None], check_unset=False)

        return self._replace(
            prev_a=selected, visited_=visited_,
            cur_load=all_loads[:,:,None],
            demands=all_demands[:,:,None],
            cur_SOC=all_SOC[:,:,None],
            cur_time=all_time[:,:,None],
            i=self.i + 1,
        ), time_cons, soc_consume, distance


    def get_mask(self):
        chosen_idx = self.prev_a
        depot = chosen_idx.eq(0)
        charging_station = (chosen_idx.gt(0) & chosen_idx.le(self.charging_num))
        station_depot = chosen_idx.le(self.charging_num)
        customer = chosen_idx.gt(self.charging_num)
        chosen_idx = chosen_idx.type(torch.long)

        loads = self.cur_load[:, :, 0]
        demands = self.demands[:, :, 0]
        SOC = self.cur_SOC[:, :, 0]
        time = self.cur_time[:, :, 0]

        if demands.eq(0).all():
            return demands * 0.

        new_mask = demands.ne(0) * demands.lt(loads)

        new_mask[station_depot, 1: self.charging_num + 1] = 0
        new_mask[charging_station, 0] = 1
        new_mask[customer, :self.charging_num + 1] = 1
        new_mask[depot, 0] = 0

        has_no_load = loads[:, 0].eq(0).float()
        has_no_demand = demands[:, self.charging_num:].sum(1).eq(0).float()
        combined = (has_no_load + has_no_demand).gt(0)
        if combined.any():
            new_mask[combined.nonzero(as_tuple=False), 0] = 1
            new_mask[combined.nonzero(as_tuple=False), 1:] = 0

        # the point where the next decoding power or time cannot be directly reached
        distance0 = self.distances[torch.arange(self.distances.size(0)), chosen_idx].clone()
        slope1 = self.slope[torch.arange(self.distances.size(0)), chosen_idx]
        time_cons0 = distance0 / GlobalVars.velocity
        mass0 = (GlobalVars.mc + loads[:, 0] * GlobalVars.max_load * GlobalVars.w) \
            .unsqueeze(1).expand_as(distance0)
        soc_consume0 = self.calculate_soc_consume(mass0, slope1, time_cons0)
        SOC_cons0 = soc_consume0

        # the next decoding is because the return depot time or not enough
        time_cons1 = distance0 / GlobalVars.velocity
        slope1 = self.slope[torch.arange(self.distances.size(0)), chosen_idx]
        mass1 = (GlobalVars.mc + loads[:, 0] * GlobalVars.max_load * GlobalVars.w).unsqueeze(1).expand_as(distance0)
        soc_consume1 = self.calculate_soc_consume(mass1, slope1, time_cons1)
        SOC_cons1 = soc_consume1
        # energy consumption from this point back to the depot
        time_cons2 = self.distances[:, 0, :] / GlobalVars.velocity
        slope2 = self.slope[torch.arange(self.distances.size(0)), 0]
        mass2 = (GlobalVars.mc + (loads - demands) * GlobalVars.max_load * GlobalVars.w)
        soc_consume2 = self.calculate_soc_consume(mass2, slope2, time_cons2)
        SOC_cons2 = soc_consume2
        SOC_cons3 = SOC_cons1 + SOC_cons2
        SOC_cons3[:, 0: self.charging_num + 1] = 0
        time_cons3 = (self.distances[torch.arange(self.distances.size(0)), chosen_idx] + self.distances[:, 0, :]) / GlobalVars.velocity
        SOC_to_station = SOC[:, 1:self.charging_num+1] - soc_consume1[:, 1:self.charging_num+1]
        SOC_needed = GlobalVars.Start_SOC - SOC_to_station
        time_to_charge = SOC_needed / GlobalVars.Start_SOC * self.distin[:, 1: self.charging_num+1, 0]
        time_cons3[:, 1: self.charging_num + 1] += time_to_charge
        time_cons3[:, self.charging_num + 1:] += self.serve_time[:, self.charging_num + 1:, 0]

        # The next decoding detours to the nearest charging station
        #     and cannot return to the depot due to time or power
        distances_station = [self.distances[:, i:i + 1, :]
                             for i in range(1, self.charging_num + 1)]
        distances_station = torch.cat(distances_station, dim=1)
        distances_station = torch.min(distances_station, dim=1)
        distances_station[0][:, 0] = 0
        distance3 = distances_station[0]
        slope3 = self.slope[:, 1:self.charging_num + 1, :] \
            .gather(1, distances_station[1].unsqueeze(1)).squeeze(1)
        distance4 = self.distances[:, 1:self.charging_num + 1, 0:1] \
            .gather(1, distances_station[1].unsqueeze(1)[:, :, 0:1]).squeeze(1)
        time_cons4 = distance3 / GlobalVars.velocity
        soc_consume4 = self.calculate_soc_consume(mass2, slope3, time_cons4)
        SOC_cons4 = soc_consume4

        SOC_cons5 = SOC_cons1 + SOC_cons4

        time_cons5 = (distance0 + distance3 + distance4) / GlobalVars.velocity
        nearest_station_index = distances_station[1]
        station_distin = self.distin[:, 1:self.charging_num+1, 0]
        nearest_station_distin = torch.gather(station_distin, dim=1, index=nearest_station_index)
        SOC_needed2 = torch.clamp(GlobalVars.Start_SOC - SOC_cons5, min=0, max=GlobalVars.Start_SOC)
        time_to_charge2 = SOC_needed2 / GlobalVars.Start_SOC * nearest_station_distin
        time_cons5[:, self.charging_num + 1:] += (time_to_charge2[:, self.charging_num+1:] + self.serve_time[:,self.charging_num+1:, 0])

        new_mask[(SOC < SOC_cons0) | (time < time_cons0)] = 0
        new_mask[((SOC < SOC_cons3) | (time < time_cons3)) & ((SOC < SOC_cons5) | (time < time_cons5))] = 0

        all_masked = new_mask[:, self.charging_num + 1:].eq(1).sum(1).le(0)

        new_mask[all_masked, 0] = 1

        return new_mask[:, None, :]

    def calculate_soc_consume(self, mass, slope, time_cons):

        Pm = (GlobalVars.Pm_param1 +
              mass * GlobalVars.g * slope + mass * GlobalVars.Pm_param2) \
             * GlobalVars.velocity
        positive_index = Pm.gt(0.)
        negative_index = Pm.lt(0.)
        soc_consume = torch.zeros_like(Pm)
        soc_consume[positive_index] = GlobalVars.positive_param * Pm[positive_index] * time_cons[positive_index] / 3600.
        soc_consume[negative_index] = GlobalVars.negative_param * Pm[negative_index] * time_cons[negative_index] / 3600.
        return soc_consume

    def construct_solutions(self, actions):
        return actions
