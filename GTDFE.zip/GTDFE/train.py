#!/usr/bin/env python

import torch
from options import get_options
from utils.utils import *
from Trainer import Trainer

os.environ["CUDA_VISIBLE_DEVICES"] = '0'
os.chdir(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, "../..")  # for problem_def
sys.path.insert(0, "../../..")  # for utils

model_load = {
    'enable': False,  # enable loading pre-trained model
    # 'path': './result/20230815_094931_train_n20',  # directory path of pre-trained model and log files saved.
    # 'epoch': 5,  # epoch version of pre-trained model to laod.
}
logger_params = {
    'log_file': {
        'desc': 'train_n20',
        'filename': 'run_log'
    },
    'logging': {
        'model_save_interval': 10,
        'img_save_interval': 10,
        'log_image_params_1': {
            'json_foldername': 'log_image_style',
            'filename': 'style_tsp_20.json'
        },
        'log_image_params_2': {
            'json_foldername': 'log_image_style',
            'filename': 'style_loss_1.json'
        },
    }
}


def run(opts):
    # create logger and set params
    create_logger(logger_params['log_file'])
    _print_config()

    # Set the random seed
    torch.manual_seed(opts.seed)

    # Save arguments so exact configuration can always be found
    with open(os.path.join(get_result_folder(), "args.json"), 'w') as f:
        json.dump(vars(opts), f, indent=True)

    trainer = Trainer(opts=opts,
                      model_load=model_load,
                      logger_params=logger_params)

    trainer.run()


def _print_config():
    logger = logging.getLogger('root')
    [logger.info(g_key + "{}".format(globals()[g_key])) for g_key in globals().keys() if g_key.endswith('params')]


if __name__ == "__main__":
    start = time.time()
    run(get_options())
    end = time.time() - start
    print('runtime:', end)

