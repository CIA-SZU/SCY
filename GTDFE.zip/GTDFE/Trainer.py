import math
from tqdm import tqdm
import torch
import torch.optim as optim
from torch.utils.data import DataLoader
from torch.nn import DataParallel
from nets.attention_model import set_decode_type
from utils import move_to
from nets.critic_network import CriticNetwork
from reinforce_baselines import NoBaseline, ExponentialBaseline, CriticBaseline, RolloutBaseline, WarmupBaseline
from nets.attention_model import AttentionModel
from nets.pointer_network import PointerNetwork, CriticNetworkLSTM
from utils import torch_load_cpu, load_problem
from utils.utils import *
from logging import getLogger


class Trainer:
    def __init__(self,
                 opts,
                 model_load, logger_params):

        # save arguments
        self.opts = opts
        self.logger_params = logger_params

        torch.manual_seed(opts.seed)

        self.logger = getLogger(name='trainer')
        self.result_folder = get_result_folder()
        self.result_log_epoch = LogData()
        self.result_log_step = LogData()

        # Set the device
        opts.device = torch.device("cuda:0" if opts.use_cuda else "cpu")

        # Main Components
        # Figure out what's the problem
        self.problem = load_problem(opts.problem)

        self.load_data = {}
        assert opts.load_path is None or opts.resume is None, "Only one of load path and resume can be given"
        load_path = opts.load_path if opts.load_path is not None else opts.resume
        if load_path is not None:
            print('  [*] Loading data from {}'.format(load_path))
            self.load_data = torch_load_cpu(load_path)

        model_class = {
            'attention': AttentionModel,
            'pointer': PointerNetwork
        }.get(opts.model, None)
        assert model_class is not None, "Unknown model: {}".format(model_class)
        self.model = model_class(
            opts.embedding_dim,
            opts.hidden_dim,
            self.problem,
            n_encode_layers=opts.n_encode_layers,
            mask_inner=True,
            mask_logits=True,
            normalization=opts.normalization,
            tanh_clipping=opts.tanh_clipping,
            checkpoint_encoder=opts.checkpoint_encoder,
            n_charging_station=opts.station_size,
            shrink_size=opts.shrink_size
        ).to(opts.device)

        if opts.use_cuda and torch.cuda.device_count() > 1:
            self.model = torch.nn.DataParallel(self.model)

        if opts.baseline == 'exponential':
            self.baseline = ExponentialBaseline(opts.exp_beta)
        elif opts.baseline == 'critic' or opts.baseline == 'critic_lstm':
            assert self.problem.NAME == 'tsp', "Critic only supported for TSP"
            self.baseline = CriticBaseline(
                (
                    CriticNetworkLSTM(
                        2,
                        opts.embedding_dim,
                        opts.hidden_dim,
                        opts.n_encode_layers,
                        opts.tanh_clipping
                    )
                    if opts.baseline == 'critic_lstm'
                    else
                    CriticNetwork(
                        2,
                        opts.embedding_dim,
                        opts.hidden_dim,
                        opts.n_encode_layers,
                        opts.normalization
                    )
                ).to(opts.device)
            )
        elif opts.baseline == 'rollout':
            self.baseline = RolloutBaseline(self.model, self.problem, opts)
        else:
            assert opts.baseline is None, "Unknown baseline: {}".format(opts.baseline)
            self.baseline = NoBaseline()

        if opts.bl_warmup_epochs > 0:
            self.baseline = WarmupBaseline(self.baseline, opts.bl_warmup_epochs, warmup_exp_beta=opts.exp_beta)

        self.optimizer = optim.Adam(
            [{'params': self.model.parameters(), 'lr': opts.lr_model}]
            + (
                [{'params': self.baseline.get_learnable_parameters(), 'lr': opts.lr_critic}]
                if len(self.baseline.get_learnable_parameters()) > 0
                else []
            )
        )

        self.lr_scheduler = optim.lr_scheduler.LambdaLR(self.optimizer, lambda epoch: opts.lr_decay ** epoch)

        # Start the actual training loop
        self.val_dataset = self.problem.make_dataset(
            size=opts.graph_size, p_size=opts.station_size, num_samples=opts.val_size, filename=opts.val_dataset)

        # Restore
        if model_load['enable']:
            checkpoint_fullname = '{path}/epoch-{epoch}.pt'.format(**model_load)
            checkpoint = torch.load(checkpoint_fullname, map_location=opts.device)
            epoch_resume = model_load['epoch']
            torch.set_rng_state(checkpoint['rng_state'].type(torch.ByteTensor))
            if opts.use_cuda:
                for i in range(len(checkpoint['cuda_rng_state'])):
                    print(checkpoint['cuda_rng_state'][i].type())
                    checkpoint['cuda_rng_state'][i] = checkpoint['cuda_rng_state'][0].type(torch.ByteTensor)
                    print(checkpoint['cuda_rng_state'][i].type())
                torch.cuda.set_rng_state_all(checkpoint['cuda_rng_state'])
            model_ = self.get_inner_model(self.model)
            model_.load_state_dict({**model_.state_dict(), **checkpoint.get('model', {})})
            self.baseline.load_state_dict(checkpoint['baseline'])
            self.optimizer.load_state_dict(checkpoint['optimizer'])
            for state in self.optimizer.state.values():
                for k, v in state.items():
                    if torch.is_tensor(v):
                        state[k] = v.to(opts.device)
            # Dumping of state was done before epoch callback, so do that now (model is loaded)
            self.baseline.epoch_callback(self.model, epoch_resume)
            self.result_log_epoch.set_raw_data(checkpoint['result_log_epoch'])
            self.result_log_step.set_raw_data(checkpoint['result_log_step'])
            print("Resuming after {}".format(epoch_resume))
            self.logger.info('Saved Model Loaded !!')
            opts.epoch_start = epoch_resume + 1

        self.time_estimator = TimeEstimator()

    def run(self):
        self.time_estimator.reset(self.opts.epoch_start)
        if self.opts.eval_only:
            self.validate(self.model, self.val_dataset, self.opts)
        else:
            for epoch in range(self.opts.epoch_start, self.opts.n_epochs):
                self.train_epoch(epoch)

    def train_epoch(self, epoch):

        self.logger.info(' ')
        self.logger.info('=================================================================')
        self.logger.info('Epoch {:3d}: lr ({:.4f}%) '
                         .format(epoch, self.optimizer.param_groups[0]['lr']))
        step = epoch * (self.opts.epoch_size // self.opts.batch_size)

        training_dataset = self.baseline.wrap_dataset(self.problem.make_dataset(
            size=self.opts.graph_size, p_size=self.opts.station_size, num_samples=self.opts.epoch_size))
        training_dataloader = DataLoader(training_dataset, batch_size=self.opts.batch_size, num_workers=1)

        # Put model in train mode!
        self.model.train()
        set_decode_type(self.model, "sampling")
        score_AM = AverageMeter()
        loss_AM = AverageMeter()
        soc_AM = AverageMeter()
        length_AM = AverageMeter()
        # train batch for one epoch
        for batch_id, batch in enumerate(tqdm(training_dataloader, disable=self.opts.no_progress_bar)):
            avg_score, avg_loss, soc_cost, length_cost = self.train_batch(batch)
            self.result_log_step.append('train_score', step, avg_score)
            self.result_log_step.append('train_loss', step, avg_loss)
            self.result_log_step.append('train_soc', epoch, soc_cost)
            self.result_log_step.append('train_length', epoch, length_cost)
            batch_size = self.opts.batch_size
            score_AM.update(avg_score, batch_size)
            loss_AM.update(avg_loss, batch_size)
            soc_AM.update(soc_cost, batch_size)
            length_AM.update(length_cost, batch_size)
            step += 1

        train_score, train_loss, soc_cost, length_cost = score_AM.avg, loss_AM.avg,soc_AM.avg, length_AM.avg
        self.logger.info('Finished Epoch {:3d}: Train ({:3.0f}%) Score: {:.4f}, Loss: {:.4f}, soc_cost: {:.4f}, length_cost: {:.4f}'
                         .format(epoch, 100. * step / self.opts.epoch_size,
                                 train_score, train_loss, soc_cost, length_cost))
        self.result_log_epoch.append('train_score', epoch, train_score)
        self.result_log_epoch.append('train_loss', epoch, train_loss)
        self.result_log_epoch.append('train_soc', epoch, soc_cost)
        self.result_log_epoch.append('train_length', epoch, length_cost)


        elapsed_time_str, remain_time_str = self.time_estimator.get_est_string(epoch, self.opts.n_epochs)
        self.logger.info("Epoch {:3d}/{:3d}: Time Est.: Elapsed[{}], Remain[{}]".format(
            epoch, self.opts.n_epochs, elapsed_time_str, remain_time_str))

        all_done = (epoch == self.opts.n_epochs - 1)

        if epoch > 0:
            self.logger.info("Saving log_image")
            image_prefix_epoch = '{}/epoch_latest'.format(self.result_folder)
            util_save_log_image_with_label(image_prefix_epoch, self.logger_params['logging']['log_image_params_1'],
                                           self.result_log_epoch, labels=['train_score'])
            util_save_log_image_with_label(image_prefix_epoch, self.logger_params['logging']['log_image_params_2'],
                                           self.result_log_epoch, labels=['train_loss'])
            util_save_log_image_with_label(image_prefix_epoch, self.logger_params['logging']['log_image_params_1'],
                                           self.result_log_epoch, labels=['train_soc'])
            util_save_log_image_with_label(image_prefix_epoch, self.logger_params['logging']['log_image_params_1'],
                                           self.result_log_epoch, labels=['train_length'])

        if (self.opts.checkpoint_epochs != 0 and epoch % self.opts.checkpoint_epochs == 0) or all_done:
            self.logger.info(" Saving model and state... ")
            torch.save(
                {
                    'epoch': epoch,
                    'model': self.get_inner_model(self.model).state_dict(),
                    'optimizer': self.optimizer.state_dict(),
                    'rng_state': torch.get_rng_state(),
                    'cuda_rng_state': torch.cuda.get_rng_state_all(),
                    'baseline': self.baseline.state_dict(),
                    'result_log_epoch': self.result_log_epoch.get_raw_data(),
                    'result_log_step': self.result_log_step.get_raw_data()
                },
                os.path.join(self.result_folder, 'epoch-{}.pt'.format(epoch))
            )

        if all_done:
            self.logger.info(" *** Training Done *** ")
            self.logger.info("Now, printing log array...")
            util_print_log_array(self.logger, self.result_log_epoch)


        avg_reward = self.validate(self.model, self.val_dataset, self.opts)
        self.logger.info('val_avg_reward {}: step {}'.format(avg_reward, step))

        self.baseline.epoch_callback(self.model, epoch)
        self.lr_scheduler.step()

    def train_batch(self, batch):
        x, bl_val = self.baseline.unwrap_batch(batch)
        x = move_to(x, self.opts.device)  # memory will up
        bl_val = move_to(bl_val, self.opts.device) if bl_val is not None else None  # memory will up

        pi, log_likelihood, time_cost, soc_cost, length_cost = self.model(x)
        bl_val, bl_loss = self.baseline.eval(x, time_cost) if bl_val is None else (bl_val, 0)
        reinforce_loss = ((time_cost - bl_val) * log_likelihood).mean()
        loss = reinforce_loss + bl_loss

        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

        return time_cost.mean().item(), reinforce_loss.item(), soc_cost.mean().item(), length_cost.mean().item()

    def get_inner_model(self, model):
        return model.module if isinstance(model, DataParallel) else model

    def validate(self, model, dataset, opts):
        cost = self.rollout(model, dataset, opts)
        avg_cost = cost.mean()
        return avg_cost

    def rollout(self, model, dataset, opts):
        # Put in greedy evaluation mode!
        set_decode_type(model, "greedy")
        model.eval()

        def eval_model_bat(bat):
            with torch.no_grad():
                _, _, cost, _, _ = model(move_to(bat, opts.device))
            return cost.data.cpu()

        return torch.cat([
            eval_model_bat(bat)
            for bat
            in tqdm(DataLoader(dataset, batch_size=opts.eval_batch_size), disable=opts.no_progress_bar)
        ], 0)

    def clip_grad_norms(self, param_groups, max_norm=math.inf):
        """
        Clips the norms for all param groups to max_norm and returns gradient norms before clipping
        :param optimizer:
        :param max_norm:
        :param gradient_norms_log:
        :return: grad_norms, clipped_grad_norms: list with (clipped) gradient norms per group
        """
        grad_norms = [
            torch.nn.utils.clip_grad_norm_(
                group['params'],
                max_norm if max_norm > 0 else math.inf,  # Inf so no clipping but still call to calc
                norm_type=2
            )
            for group in param_groups
        ]
        grad_norms_clipped = [min(g_norm, max_norm) for g_norm in grad_norms] if max_norm > 0 else grad_norms
        return grad_norms, grad_norms_clipped


